import { Component, OnInit } from '@angular/core';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  emailID:string;
  password:string;
  errorMessage: string;
  addMessage: string;
  constructor(private route:ActivatedRoute, private router:Router, private productService: CapbookServicesService) { }
  get _emailID():string{
    return this.emailID;
  }
  set _emailID(value:string){
    this.emailID=value;
  }
  get _password():string{
    return this.password;
  }
  set _password(value:string){
    this._password=value;
  }
  onClick(){
    const user1:any={
      productId:this.emailID,
      price:this.password
    
    }
   
    this.productService.login(user1).subscribe(
      tempMessage=>{
        this.addMessage="Logged In Successfully!!";       
        } 
    ,
      error=>{
        this.errorMessage=error;
      }
  );
  }

  ngOnInit() {
  }

  public navigateBack(): void{
    this.router.navigate(['/dashboard']);
  }
}
