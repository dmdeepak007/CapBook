import { Component, OnInit } from '@angular/core';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  _emailID:string;
  _password:string;
  errorMessage: string;
  addMessage: string;
  constructor(private route:ActivatedRoute, private router:Router, private capbookService: CapbookServicesService) { }
  get emailID():string{
    return this._emailID;
  }
  set emailID(value:string){
    this._emailID=value;
  }
  get password():string{
    return this._password;
  }
  set password(value:string){
    this._password=value;
  }
  onClick(){
    const user1: any={
      emailID:this.emailID,
      password:this.password 
    }
   
    this.capbookService.login(user1).subscribe(
      tempMessage=>{
        this.addMessage="Logged In Successfully!!";     
        console.log(this.addMessage);  
        this.router.navigate(['/dashboard']);
        } 
    ,
      error=>{
        this.errorMessage=error;
        console.log("error");
      }
  );
  }

  ngOnInit() {
  }

 
}
