import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { SignupComponent } from './UserActivities/signup/signup.component';
import { SigninComponent } from './UserActivities/signin/signin.component';
import { CapbookServicesService } from './services/capbook-services.service';
import { WelcomeComponent } from './UserActivities/welcome/welcome.component';
import { DashboardComponent } from './UserActivities/dashboard/dashboard.component';
import { ForgotPasswordComponent } from './UserActivities/forgotPassword/forgot-password.component';
import {MatRadioModule} from '@angular/material/radio';
import { SidebarComponent } from './UserActivities/sidebar/sidebar.component';
import { HeaderComponent } from './UserActivities/header/header.component';


@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    SigninComponent,
    WelcomeComponent,
    DashboardComponent,
    ForgotPasswordComponent,
    SidebarComponent,
    HeaderComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatRadioModule,
    RouterModule.forRoot([
      {path: 'welcome', component: WelcomeComponent},
      {path: 'dashboard', component: DashboardComponent},
    {path: 'signin', component: SigninComponent },
    {path: 'signup',component:SignupComponent},
    {path: 'forgotPassword', component: ForgotPasswordComponent},
    {path: 'sidebar', component: SidebarComponent},
    {path: '', redirectTo: 'welcome', pathMatch: 'full'},
    {path: 'header', component:HeaderComponent}
  ])
  ],
  providers: [CapbookServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
